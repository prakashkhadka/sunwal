<?php

namespace Intervention\Image\Exception;

class NotSupportedException extends ImageException
{
    # nothing to override
}
